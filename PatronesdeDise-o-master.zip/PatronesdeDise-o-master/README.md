# PatronesdeDiseño
 Esta es la tarea de los ejemplos de patrones de diseños en la cual yo utilice los sigtes patrones: Adapter, Facade, Repository
